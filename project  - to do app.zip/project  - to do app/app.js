
function addTask(){
    var task = document.getElementById("task");

    var taskName = document.createElement("li");
    taskName.id = "taskName";
    taskName.innerHTML = document.getElementById("task").value;
    document.getElementById("taskList").appendChild(taskName);

    if(task.value === ""){
        alert("enter something");
        
    }

    var link = document.createElement("a");
    link.id = "link";
    link.innerHTML = "<i class = 'fa fa-remove' ></i>";
    taskName.appendChild(link); //can directly append into variable taskName
    link.onclick = removeTask;

    //clearing input field on adding
    task.value = "";
   
}

function removeTask(){
   document.getElementById("taskName").remove();
}

function saveTask(){
    localStorage.box = document.getElementById("taskList").innerHTML;
}

// function filterTasks(e){
//     var filterInput = document.getElementById("filter");
//     console.log(filterInput);
//    if(filterInput.value  === taskName.innerHTML){
//        console.log("task found");
//    }
// }
// filterInput.addEventListener("keydown", function(e){
//     if(e.keyCode == 13){
//         filterTasks(e);
//     }
// });

function clearTask(){
    taskList.innerHTML = "";
}
